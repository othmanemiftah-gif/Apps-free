# Applis gratuites (Android, Kotlin)

Construire l’APK sans Android Studio :
1. Créez un dépôt GitHub et envoyez-y tout ce dossier (y compris .github).
2. Onglet Actions → « Build APK » → attendez la fin.
3. Téléchargez l’artefact « FreeApps-apk », décompressez-le, installez l’APK.

Avec Android Studio : ouvrez le dossier, puis Build → Build APK(s).
