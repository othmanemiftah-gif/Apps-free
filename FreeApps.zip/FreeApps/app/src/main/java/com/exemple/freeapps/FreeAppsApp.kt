package com.exemple.freeapps

import android.app.Application
import com.exemple.freeapps.work.Notifier
import com.exemple.freeapps.work.Prefs
import com.exemple.freeapps.work.Scheduler

class FreeAppsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannel(this)
        if (Prefs.notif(this)) Scheduler.schedule(this, Prefs.hours(this))
    }
}
