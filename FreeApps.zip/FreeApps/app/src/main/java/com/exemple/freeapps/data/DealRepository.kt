package com.exemple.freeapps.data

import android.content.Context
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory

class DealRepository(ctx: Context) {
    private val dao = AppDatabase.get(ctx).dao()
    val deals = dao.all()

    private val api: RedditApi = Retrofit.Builder()
        .baseUrl("https://www.reddit.com/")
        .client(OkHttpClient.Builder().addInterceptor {
            it.proceed(it.request().newBuilder().header("User-Agent", "android:com.exemple.freeapps:1.0").build())
        }.build())
        .addConverterFactory(Json { ignoreUnknownKeys = true }.asConverterFactory("application/json".toMediaType()))
        .build().create(RedditApi::class.java)

    private val free = Regex("""\b(free|gratuit)\b|100\s?%|[$€£]\s?0(?:[.,]0+)?(?!\d)""", RegexOption.IGNORE_CASE)
    private val play = Regex("""https?://play\.google\.com/store/apps/details\?[^\s)\]>"]+""")
    private val price = Regex("""[$€£]\s?\d+(?:[.,]\d{1,2})?""")
    private val brackets = Regex("""\[[^\]]*]|\([^)]*\)""")
    private val tail = Regex("""\s*[-–—:|]\s*(free|100\s?%.*)$""", RegexOption.IGNORE_CASE)

    private fun toDeal(p: Post, seen: Boolean): Deal? {
        if (Regex("expired|ended|over", RegexOption.IGNORE_CASE).containsMatchIn(p.flair ?: "")) return null
        if (!free.containsMatchIn(p.title)) return null
        val link = (play.find(p.url) ?: play.find(p.selftext))?.value ?: return null
        val id = Regex("[?&]id=([^&]+)").find(link)?.groupValues?.get(1) ?: link
        val old = price.findAll(p.title).map { it.value }.firstOrNull {
            (it.replace(Regex("[^\\d.,]"), "").replace(',', '.').toDoubleOrNull() ?: 0.0) > 0
        } ?: ""
        val name = p.title.replace(brackets, " ").replace(tail, "").replace(Regex("\\s+"), " ").trim()
            .ifEmpty { p.title }
        return Deal(id, name, link, old, p.created.toLong(), seen)
    }

    /** Télécharge les promos ; renvoie le nombre de nouvelles (0 au tout premier lancement). */
    suspend fun refresh(): Int {
        val first = dao.count() == 0
        val deals = api.latest().data.children.mapNotNull { toDeal(it.data, first) }.distinctBy { it.id }
        val added = dao.insertIgnore(deals).count { it != -1L }
        dao.purge(System.currentTimeMillis() / 1000 - 30 * 86400)
        return if (first) 0 else added
    }

    suspend fun markAllSeen() = dao.markAllSeen()
    suspend fun toggleFav(id: String) = dao.toggleFav(id)
}
