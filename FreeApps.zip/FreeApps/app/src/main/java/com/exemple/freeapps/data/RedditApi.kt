package com.exemple.freeapps.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import retrofit2.http.GET
import retrofit2.http.Query

@Serializable data class Listing(val data: ListingData)
@Serializable data class ListingData(val children: List<Child>)
@Serializable data class Child(val data: Post)
@Serializable
data class Post(
    val title: String = "",
    val url: String = "",
    val selftext: String = "",
    @SerialName("created_utc") val created: Double = 0.0,
    @SerialName("link_flair_text") val flair: String? = null
)

interface RedditApi {
    @GET("r/googleplaydeals/new.json")
    suspend fun latest(@Query("limit") limit: Int = 75, @Query("raw_json") raw: Int = 1): Listing
}
