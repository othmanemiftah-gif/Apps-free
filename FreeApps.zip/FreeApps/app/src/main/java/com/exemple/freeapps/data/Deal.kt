package com.exemple.freeapps.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "deals")
data class Deal(
    @PrimaryKey val id: String,
    val name: String,
    val link: String,
    val oldPrice: String,
    val time: Long,
    val seen: Boolean = false,
    val favorite: Boolean = false
)
