package com.exemple.freeapps

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import com.exemple.freeapps.ui.DealsScreen
import com.exemple.freeapps.ui.DealsViewModel
import com.exemple.freeapps.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    private val vm: DealsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                DealsScreen(vm)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        vm.markSeen()
    }
}
