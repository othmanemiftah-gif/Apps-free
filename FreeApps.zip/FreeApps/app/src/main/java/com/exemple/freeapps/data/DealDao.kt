package com.exemple.freeapps.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DealDao {
    @Query("SELECT * FROM deals ORDER BY time DESC") fun all(): Flow<List<Deal>>
    @Query("SELECT COUNT(*) FROM deals") suspend fun count(): Int
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertIgnore(d: List<Deal>): List<Long>
    @Query("UPDATE deals SET seen = 1") suspend fun markAllSeen()
    @Query("UPDATE deals SET favorite = NOT favorite WHERE id = :id") suspend fun toggleFav(id: String)
    @Query("DELETE FROM deals WHERE favorite = 0 AND time < :before") suspend fun purge(before: Long)
}
