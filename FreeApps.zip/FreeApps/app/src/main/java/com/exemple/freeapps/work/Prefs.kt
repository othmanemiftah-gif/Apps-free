package com.exemple.freeapps.work

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun notif(c: Context) = sp(c).getBoolean("notif", true)
    fun setNotif(c: Context, v: Boolean) = sp(c).edit().putBoolean("notif", v).apply()
    fun hours(c: Context) = sp(c).getInt("hours", 3)
    fun setHours(c: Context, v: Int) = sp(c).edit().putInt("hours", v).apply()
}
