package com.exemple.freeapps.work

import android.content.Context
import androidx.work.*
import com.exemple.freeapps.data.DealRepository
import java.util.concurrent.TimeUnit

class CheckDealsWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        val n = DealRepository(applicationContext).refresh()
        if (n > 0 && Prefs.notif(applicationContext)) Notifier.notifyNew(applicationContext, n)
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }
}

object Scheduler {
    fun schedule(c: Context, hours: Int) {
        val req = PeriodicWorkRequestBuilder<CheckDealsWorker>(hours.toLong(), TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("check", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
    fun cancel(c: Context) { WorkManager.getInstance(c).cancelUniqueWork("check") }
}
