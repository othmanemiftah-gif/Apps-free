package com.exemple.freeapps.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.exemple.freeapps.data.DealRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Filter(val label: String) { ALL("Toutes"), NEW("Nouvelles"), FAV("Favorites") }

class DealsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = DealRepository(app)
    val query = MutableStateFlow("")
    val filter = MutableStateFlow(Filter.ALL)
    val refreshing = MutableStateFlow(false)
    val error = MutableStateFlow(false)

    val items = combine(repo.deals, query, filter) { list, q, f ->
        list.filter {
            (q.isBlank() || it.name.contains(q, ignoreCase = true)) &&
                when (f) { Filter.ALL -> true; Filter.NEW -> !it.seen; Filter.FAV -> it.favorite }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init { refresh() }

    fun refresh() = viewModelScope.launch {
        refreshing.value = true; error.value = false
        try { repo.refresh() } catch (e: Exception) { error.value = true }
        refreshing.value = false
    }
    fun markSeen() { viewModelScope.launch { repo.markAllSeen() } }
    fun toggleFav(id: String) { viewModelScope.launch { repo.toggleFav(id) } }
}
