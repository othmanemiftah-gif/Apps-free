package com.exemple.freeapps.work

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.exemple.freeapps.MainActivity

object Notifier {
    private const val CH = "deals"

    fun createChannel(c: Context) {
        c.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Nouvelles promos", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun notifyNew(c: Context, count: Int) {
        val mgr = NotificationManagerCompat.from(c)
        if (!mgr.areNotificationsEnabled()) return
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val title = if (count > 1) "$count nouvelles applis gratuites" else "1 nouvelle appli gratuite"
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText("Touchez pour les voir")
            .setContentIntent(pi).setAutoCancel(true).build()
        mgr.notify(1, n)
    }
}
