package com.exemple.freeapps.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.exemple.freeapps.data.Deal
import com.exemple.freeapps.work.Prefs
import com.exemple.freeapps.work.Scheduler

fun ago(ts: Long): String {
    val s = (System.currentTimeMillis() / 1000 - ts).coerceAtLeast(0)
    return when {
        s < 3600 -> "il y a ${maxOf(1, s / 60)} min"
        s < 86400 -> "il y a ${s / 3600} h"
        else -> "il y a ${s / 86400} j"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DealsScreen(vm: DealsViewModel) {
    val items by vm.items.collectAsState()
    val query by vm.query.collectAsState()
    val filter by vm.filter.collectAsState()
    val refreshing by vm.refreshing.collectAsState()
    val error by vm.error.collectAsState()
    var settings by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Applis gratuites") },
            actions = { IconButton(onClick = { settings = true }) { Icon(Icons.Default.Settings, "Réglages") } }
        )
    }) { pad ->
        PullToRefreshBox(isRefreshing = refreshing, onRefresh = { vm.refresh() }, modifier = Modifier.padding(pad)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = query, onValueChange = { vm.query.value = it },
                        label = { Text("Rechercher") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Filter.entries.forEach { f ->
                            FilterChip(selected = filter == f, onClick = { vm.filter.value = f }, label = { Text(f.label) })
                        }
                    }
                }
                if (error) item {
                    Text("Actualisation impossible. Les dernières promos enregistrées sont affichées.", color = MaterialTheme.colorScheme.error)
                }
                if (items.isEmpty() && !refreshing) item {
                    Text("Aucune appli à afficher. Tirez vers le bas pour actualiser.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(items, key = { it.id }) { d -> DealCard(d) { vm.toggleFav(d.id) } }
            }
        }
    }
    if (settings) SettingsDialog { settings = false }
}

@Composable
fun DealCard(d: Deal, onFav: () -> Unit) {
    val ctx = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(d.name, style = MaterialTheme.typography.titleMedium)
                    val meta = (if (!d.seen) "Nouveau · " else "") + ago(d.time) +
                        (if (d.oldPrice.isNotEmpty()) " · avant ${d.oldPrice}" else "")
                    Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onFav) {
                    Icon(
                        Icons.Default.Star, "Favori",
                        tint = if (d.favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(d.link))) }) {
                    Text("Ouvrir dans le Play Store")
                }
                IconButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "${d.name} est gratuite : ${d.link}")
                    }
                    ctx.startActivity(Intent.createChooser(send, null))
                }) { Icon(Icons.Default.Share, "Partager") }
            }
        }
    }
}

@Composable
fun SettingsDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var notif by remember { mutableStateOf(Prefs.notif(ctx)) }
    var hours by remember { mutableIntStateOf(Prefs.hours(ctx)) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Réglages") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Notifier les nouvelles promos", Modifier.weight(1f))
                    Switch(checked = notif, onCheckedChange = { notif = it })
                }
                Text("Vérifier toutes les…")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 3, 6, 12).forEach { h ->
                        FilterChip(selected = hours == h, onClick = { hours = h }, label = { Text("$h h") })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Prefs.setNotif(ctx, notif); Prefs.setHours(ctx, hours)
                if (notif) Scheduler.schedule(ctx, hours) else Scheduler.cancel(ctx)
                onClose()
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Annuler") } }
    )
}
